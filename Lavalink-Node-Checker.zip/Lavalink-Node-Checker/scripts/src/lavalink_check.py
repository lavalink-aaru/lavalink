#!/usr/bin/env python3
"""Check Lavalink-compatible nodes through their authenticated /version API.

Uses only the Python standard library. Node addresses go in a JSON config;
passwords are read from environment variables and are never printed or saved.
"""

import argparse
import asyncio
import csv
import json
import os
import socket
import ssl
import statistics
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter
from pathlib import Path


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """Do not forward an Authorization header to a redirect destination."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


OPENER = urllib.request.build_opener(NoRedirect)
CSV_FIELDS = [
    "name",
    "endpoint",
    "status",
    "successful_checks",
    "total_checks",
    "median_ms",
    "version",
    "details",
]


def clean_text(value, limit=200):
    """Keep terminal control characters out of displayed server responses."""
    value = "".join(ch for ch in value if ch in "\t" or ord(ch) >= 32)
    return " ".join(value.split())[:limit]


def validate_config(config):
    nodes = config.get("nodes") if isinstance(config, dict) else None
    if not isinstance(nodes, list) or not nodes:
        raise ValueError("Config must contain a non-empty 'nodes' array.")

    names = set()
    for index, node in enumerate(nodes, start=1):
        if not isinstance(node, dict):
            raise ValueError(f"Node {index} must be a JSON object.")

        name = node.get("name")
        url = node.get("url")
        password_env = node.get("password_env")
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f"Node {index} needs a non-empty 'name'.")
        if name in names:
            raise ValueError(f"Node name {name!r} is duplicated.")
        names.add(name)
        if not isinstance(password_env, str) or not password_env.strip():
            raise ValueError(f"Node {name!r} needs a 'password_env' variable name.")
        if not isinstance(url, str):
            raise ValueError(f"Node {name!r} needs a 'url'.")

        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise ValueError(
                f"Node {name!r}: url must be an http:// or https:// base URL."
            )
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError(
                f"Node {name!r}: keep credentials, query strings, and fragments "
                "out of the URL."
            )
        try:
            parsed.port  # Validate malformed ports.
        except ValueError as exc:
            raise ValueError(f"Node {name!r}: invalid port in url.") from exc

    return nodes


def classify_network_error(exc):
    if isinstance(exc, (ssl.SSLError, ssl.CertificateError)):
        return "TLS_ERROR", clean_text(str(exc), 160)
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return "TIMEOUT", "Request timed out."
    if isinstance(exc, socket.gaierror):
        return "DNS_ERROR", clean_text(str(exc), 160)
    if isinstance(exc, urllib.error.URLError):
        return classify_network_error(exc.reason)
    if isinstance(exc, OSError):
        return "CONNECTION_ERROR", clean_text(str(exc), 160)
    return "ERROR", clean_text(str(exc), 160)


def probe(node, timeout):
    """Make one authenticated GET and return its status and elapsed time."""
    env_name = node["password_env"]
    password = os.environ.get(env_name)
    if not password:
        return {
            "status": "CONFIG_ERROR",
            "ms": None,
            "version": "",
            "details": f"Environment variable {env_name} is missing or empty.",
        }

    base_url = node["url"].rstrip("/")
    request = urllib.request.Request(
        f"{base_url}/version",
        headers={
            "Authorization": password,
            "Accept": "application/json, text/plain;q=0.9, */*;q=0.8",
            "User-Agent": "lavalink-node-checker/1.0",
        },
        method="GET",
    )
    started = time.perf_counter()
    try:
        with OPENER.open(request, timeout=timeout) as response:
            body = response.read(1024).decode("utf-8", errors="replace")
            elapsed_ms = round((time.perf_counter() - started) * 1000, 1)
            if response.status == 200:
                return {
                    "status": "ONLINE",
                    "ms": elapsed_ms,
                    "version": clean_text(body),
                    "details": "Authenticated /version request returned HTTP 200.",
                }
            return {
                "status": f"HTTP_{response.status}",
                "ms": elapsed_ms,
                "version": "",
                "details": f"/version returned HTTP {response.status}.",
            }
    except urllib.error.HTTPError as exc:
        elapsed_ms = round((time.perf_counter() - started) * 1000, 1)
        if exc.code in (401, 403):
            status = "AUTH_FAILED"
            details = f"Server rejected authentication (HTTP {exc.code})."
        else:
            status = f"HTTP_{exc.code}"
            details = f"/version returned HTTP {exc.code}."
            if exc.code == 404:
                details += " This endpoint may not be supported; 404 does not prove offline."
        return {
            "status": status,
            "ms": elapsed_ms,
            "version": "",
            "details": details,
        }
    except (urllib.error.URLError, ssl.SSLError, TimeoutError, socket.timeout, OSError) as exc:
        status, details = classify_network_error(exc)
        return {"status": status, "ms": None, "version": "", "details": details}
    except Exception as exc:
        return {
            "status": "ERROR",
            "ms": None,
            "version": "",
            "details": clean_text(f"{type(exc).__name__}: {exc}", 160),
        }


async def check_node(node, rounds, timeout, interval):
    samples = []
    for round_number in range(rounds):
        samples.append(await asyncio.to_thread(probe, node, timeout))
        if round_number + 1 < rounds and interval:
            await asyncio.sleep(interval)

    successful = [sample for sample in samples if sample["status"] == "ONLINE"]
    status_counts = Counter(sample["status"] for sample in samples)
    if len(successful) == rounds:
        status = "ONLINE"
    elif successful:
        status = "DEGRADED"
    else:
        status = max(status_counts, key=lambda key: status_counts[key])

    versions = [sample["version"] for sample in successful if sample["version"]]
    details = (
        f"{len(successful)}/{rounds} checks returned HTTP 200."
        if successful
        else "; ".join(f"{key} x{count}" for key, count in status_counts.items())
    )
    if not successful:
        first_detail = next(
            (sample["details"] for sample in samples if sample["details"]), ""
        )
        if first_detail:
            details += f" {first_detail}"
    elif len(successful) < rounds:
        failures = Counter(
            sample["status"] for sample in samples if sample["status"] != "ONLINE"
        )
        details += " Failures: " + ", ".join(
            f"{key} x{count}" for key, count in failures.items()
        ) + "."

    parsed = urllib.parse.urlsplit(node["url"])
    endpoint = parsed.netloc + parsed.path
    return {
        "name": node["name"],
        "endpoint": endpoint,
        "status": status,
        "successful_checks": len(successful),
        "total_checks": rounds,
        "median_ms": round(statistics.median(s["ms"] for s in successful), 1)
        if successful
        else "",
        "version": versions[-1] if versions else "",
        "details": details,
    }


async def run_checks(nodes, rounds, timeout, interval):
    return await asyncio.gather(
        *(check_node(node, rounds, timeout, interval) for node in nodes)
    )


def main():
    parser = argparse.ArgumentParser(
        description="Check Lavalink-compatible nodes using authenticated /version requests."
    )
    parser.add_argument("--config", required=True, help="JSON node config file")
    parser.add_argument(
        "--output",
        default="lavalink_results.csv",
        help="CSV output path (default: lavalink_results.csv)",
    )
    parser.add_argument("--rounds", type=int, default=3, help="Checks per node (default: 3)")
    parser.add_argument("--timeout", type=float, default=5.0, help="Seconds per request (default: 5)")
    parser.add_argument(
        "--interval",
        type=float,
        default=0.3,
        help="Seconds between rounds for each node (default: 0.3)",
    )
    args = parser.parse_args()

    if not 1 <= args.rounds <= 20:
        parser.error("--rounds must be between 1 and 20.")
    if args.timeout <= 0 or args.interval < 0:
        parser.error("--timeout must be positive and --interval cannot be negative.")

    try:
        config = json.loads(Path(args.config).read_text(encoding="utf-8"))
        nodes = validate_config(config)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        parser.error(str(exc))

    results = asyncio.run(run_checks(nodes, args.rounds, args.timeout, args.interval))
    available = [result for result in results if result["successful_checks"] > 0]
    available.sort(key=lambda result: result["median_ms"])

    print("\n=== AVAILABLE NODES: LOWEST MEDIAN API LATENCY ===")
    if not available:
        print("No authenticated HTTP 200 responses. See all results below.")
    for rank, result in enumerate(available, start=1):
        print(
            f'{rank:2}. {result["name"]:24} {result["median_ms"]:>7} ms '
            f'| {result["successful_checks"]}/{result["total_checks"]} checks '
            f'| {result["endpoint"]}'
        )

    print("\n=== ALL RESULTS ===")
    for result in results:
        latency = f'{result["median_ms"]} ms' if result["median_ms"] != "" else "-"
        print(
            f'{result["status"]:16} {latency:>9} '
            f'{result["name"]} | {result["details"]}'
        )

    output_path = Path(args.output)
    with output_path.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.DictWriter(csv_file, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(results)
    print(f"\nSaved results to {output_path}")
    print("Ranking is by median authenticated API response time, not music playback quality.")


if __name__ == "__main__":
    main()
