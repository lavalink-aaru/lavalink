# Lavalink node checker

This standalone checker measures authenticated `/version` response latency
from the machine where it runs. To get useful results for a bot hosted in
Canada, run it on that VPS rather than in Replit.

## Run

From this directory:

```bash
chmod +x run_canada_check.sh
./run_canada_check.sh
```

The launcher asks for the node passwords with terminal input hidden. They are
passed to the checker as temporary environment variables and are not stored in
the config or results. Python 3.10+ is required; no third-party packages are
needed.

The checker tests each of the 26 entries in `nodes.canada.json` five times,
prints nodes with authenticated HTTP 200 responses ranked by median response
time, and writes `lavalink_results.csv`.

An HTTP 404 means `/version` was not found; it does not prove that a node is
offline. A successful API response also does not guarantee WebSocket connection
or successful music playback.
