#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"

cleanup() {
  unset \
    LL_PASS_YOUSHALLNOTPASS \
    LL_PASS_SERENETIA \
    LL_PASS_NYX \
    LL_PASS_G3V \
    LL_PASS_TRINIUM_FREE \
    LL_PASS_TRINIUM_KIRITO \
    LL_PASS_TRINIUM_CANARY \
    LL_PASS_NEXCLOUD \
    LL_PASS_VEXA \
    LL_PASS_MINECUTA \
    LL_PASS_MILLOHOST \
    LL_PASS_NAZHA \
    LL_PASS_NAZHA_SG
}
trap cleanup EXIT

read_secret() {
  local variable_name="$1"
  local prompt="$2"
  IFS= read -r -s -p "$prompt: " "$variable_name"
  printf '\n'
  export "$variable_name"
}

read_secret LL_PASS_YOUSHALLNOTPASS "Shared youshallnotpass nodes"
read_secret LL_PASS_SERENETIA "Serenetia nodes"
read_secret LL_PASS_NYX "NodeLink SG1/SG2"
read_secret LL_PASS_G3V "G3V node"
read_secret LL_PASS_TRINIUM_FREE "Trinium free nodes"
read_secret LL_PASS_TRINIUM_KIRITO "Trinium port 2333"
read_secret LL_PASS_TRINIUM_CANARY "Trinium canary nodes"
read_secret LL_PASS_NEXCLOUD "NexCloud node"
read_secret LL_PASS_VEXA "VexaNode"
read_secret LL_PASS_MINECUTA "MineCuta"
read_secret LL_PASS_MILLOHOST "MilloHost"
read_secret LL_PASS_NAZHA "Nazha main node"
read_secret LL_PASS_NAZHA_SG "Nazha SG nodes"

python3 "$SCRIPT_DIR/src/lavalink_check.py" \
  --config "$SCRIPT_DIR/nodes.canada.json" \
  --output "$SCRIPT_DIR/lavalink_results.csv" \
  --rounds 5
